
/* .js files add interaction to your website */
var giveScript = document.getElementById("scriptGiven");
var scriptBtn = document.getElementById("scriptBtn");
var contactBtn = document.getElementById("contactBtn");
var contactInfo = document.getElementById("contactInfo");
var dropdownToggle = document.getElementById("dropdownToggle");
var dropdownMenu = document.getElementById("dropdownMenu");

if(scriptBtn){
  scriptBtn.addEventListener("click", makescript);
}

if(contactBtn){
  contactBtn.addEventListener("click", toggleContact);
}

if(dropdownToggle){
  dropdownToggle.addEventListener("click", toggleDropdown);
}

// Close dropdown when clicking outside
document.addEventListener("click", function(event) {
  if(dropdownMenu && dropdownToggle && !dropdownToggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
    dropdownMenu.classList.remove("show");
    dropdownToggle.textContent = "Menu ▼";
  }
});

function toggleContact(){
  if(contactInfo.style.display === "none"){
    contactInfo.style.display = "block";
    contactBtn.textContent = "Hide Contact Info";
  } else {
    contactInfo.style.display = "none";
    contactBtn.textContent = "Contact Me";
  }
}

function toggleDropdown(){
  if(dropdownMenu.classList.contains("show")){
    dropdownMenu.classList.remove("show");
    dropdownToggle.textContent = "Menu ▼";
  } else {
    dropdownMenu.classList.add("show");
    dropdownToggle.textContent = "Menu ▲";
  }
}

function makescript(){
  // Get user inputs and sanitize them with DOMPurify
  var name = DOMPurify.sanitize(document.getElementById("name").value, {ALLOWED_TAGS: []});
  var method = DOMPurify.sanitize(document.getElementById("method").value, {ALLOWED_TAGS: []});
  var location = DOMPurify.sanitize(document.getElementById("city").value, {ALLOWED_TAGS: []});
  var impact = DOMPurify.sanitize(document.getElementById("impact-word").value, {ALLOWED_TAGS: []});

  // Validate that required fields are not empty after sanitization
  if (!name.trim() || !method.trim() || !location.trim() || !impact.trim()) {
    giveScript.innerHTML = DOMPurify.sanitize("<p style='color: red;'>Please fill in all fields to generate your script.</p>");
    return;
  }

  // Create the script with sanitized inputs
  var scriptText = "My name is " + name + " and I'm " + method + "ing you today to exercise my civic duty as a Viewer with a Voice & Supporter of Public Media to tell you that funding must be restored for public media everywhere in the us. Not only on nationally-known organizations like NPR and PBS, but less widely acknowledge stations like Pacifica Radio and American Public Media. The Congress-led rescission of funding takes away these resources. They aren't just channels or website, but act like connective tissue; they hold communities together with honest news, lifelong learnings, and real stories for real people. I live in " + location + ". This lack of funding for public media has affected by eliminating my access to " + impact + ", and has harmed countless others in a myriad of different ways. I'm asking you to fulfill your role and bring the funding back. It's not just policy– it's people. Thank you.";
  
  // Sanitize the final output before displaying
  giveScript.innerHTML = DOMPurify.sanitize(scriptText);
}
